package is.bobbys.mod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import java.util.*;

public final class FireballTracer {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final int MARK_RADIUS = 2;
    private static final double TRACE_DISTANCE = 80.0D;
    private static final double MINSQ_DISTANCE = (8.0D)*8;
    private static final IBlockState RED_GLASS = Blocks.stained_glass.getDefaultState()
            .withProperty(BlockStainedGlass.COLOR, EnumDyeColor.RED);

    public static boolean on = true;

    private static final Map<BlockPos, IBlockState> replaced = new HashMap<>();
    private static final LinkedList<BlockPos> hits=new LinkedList<>();
    private static boolean incomingFireball=false;
    private static int tickCounter=0;
    public static final HashSet<BlockPos> breaking=new HashSet<>();

    private FireballTracer() {
    }

    public static void tick() {
        if (!on || mc.theWorld == null || mc.thePlayer == null) {
            return;
        }

        if (++tickCounter < 6) {
            return;
        }
        tickCounter = 0;

        World world = mc.theWorld;
        incomingFireball = false;
        hits.clear();
        traceExistingFireballs(world);
        traceHeldFireCharges(world);
        restoreAll(world);

        for (BlockPos h:hits){
            markArea(world, h);
        }
    }

    public static void restoreAll(World world) {
        for (Map.Entry<BlockPos, IBlockState> entry : replaced.entrySet()) {
            world.setBlockState(entry.getKey(), entry.getValue(), 2);
        }
        replaced.clear();
    }

    public static boolean hasIncomingFireball() {
        return incomingFireball;
    }

    private static void traceExistingFireballs(World world) {
        for (Object object : world.loadedEntityList) {
            if (!(object instanceof EntityFireball)) {
                continue;
            }

            EntityFireball fireball = (EntityFireball) object;
            Vec3 direction = directionOf(fireball);
            if (direction.lengthVector() < 0.0001D) {
                continue;
            }
            incomingFireball = true;
            Vec3 dir = direction.normalize();
            Vec3 start = new Vec3(fireball.posX, fireball.posY, fireball.posZ);
            Vec3 end = start.addVector(dir.xCoord * TRACE_DISTANCE, dir.yCoord * TRACE_DISTANCE, dir.zCoord * TRACE_DISTANCE);
            MovingObjectPosition hit = world.rayTraceBlocks(start, end, true, true, false);
            if (hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK&&hit.getBlockPos().distanceSq(fireball.getPosition())>MINSQ_DISTANCE) {
                hits.add(hit.getBlockPos());
            }
        }
    }

    private static void traceHeldFireCharges(World world) {
        for (EntityPlayer player : world.playerEntities) {
            ItemStack held = player.getHeldItem();
            if (held == null || held.getItem() != Items.fire_charge) {
                continue;
            }

            Vec3 start = player.getPositionEyes(1.0F);
            Vec3 look = player.getLook(1.0F);
            Vec3 end = start.addVector(look.xCoord * TRACE_DISTANCE, look.yCoord * TRACE_DISTANCE, look.zCoord * TRACE_DISTANCE);
            MovingObjectPosition hit = world.rayTraceBlocks(start, end, true, true, false);
            if (hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                hits.add(hit.getBlockPos());
            }
        }

    }

    private static Vec3 directionOf(EntityFireball fireball) {
        Vec3 motion = new Vec3(fireball.motionX, fireball.motionY, fireball.motionZ);
        if (motion.lengthVector() >= 0.0001D) {
            return motion;
        }
        return new Vec3(fireball.accelerationX, fireball.accelerationY, fireball.accelerationZ);
    }

    private static void markArea(World world, BlockPos hitPos) {
        BlockPos pos;
        IBlockState current;
        Block block;
        int dy,dz;
        for (int dx = -MARK_RADIUS; dx <= MARK_RADIUS; dx++) {
            for (dy = -MARK_RADIUS; dy <= MARK_RADIUS; dy++) {
                for (dz = -MARK_RADIUS; dz <= MARK_RADIUS; dz++) {
                    pos = hitPos.add(dx, dy, dz);
                    current = world.getBlockState(pos);
                    block = current.getBlock();
                    if (breaking.contains(pos)||replaced.containsKey(pos)){
                        continue;
                    }
                    if (block == Blocks.air || block == Blocks.stained_glass || !block.isFullCube()) {
                        continue;
                    }
                    if (!replaced.containsKey(pos)) {
                        replaced.put(pos, current);
                    }
                    world.setBlockState(pos, RED_GLASS, 4);
                    world.markBlockRangeForRenderUpdate(pos, pos);
                }
            }
        }
        world.markBlockRangeForRenderUpdate(hitPos.add(MARK_RADIUS,MARK_RADIUS,MARK_RADIUS),hitPos.add(-MARK_RADIUS,-MARK_RADIUS,-MARK_RADIUS));
    }
}
